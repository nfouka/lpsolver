<?php

require  __DIR__."/vendor/autoload.php";

$lp = lpsolve('make_lp', 0, 2);
lpsolve('set_verbose', $lp, IMPORTANT);
lpsolve('set_maxim', $lp);

$ret = lpsolve('set_obj_fn', $lp, Array(4,5));
$ret = lpsolve('add_constraint', $lp, Array(2,1), LE , 800 );
$ret = lpsolve('add_constraint', $lp, Array(1,2), LE , 700 );
$ret = lpsolve('add_constraint', $lp, Array(0,1), LE , 300 );

$ret = lpsolve('write_lp', $lp, 'a.lp');
print  lpsolve('get_mat', $lp, 1, 2) . "\n";
print  lpsolve('solve', $lp) . "\n";
print  lpsolve('get_objective', $lp) . "\n";
print_r(lpsolve('get_variables', $lp));
print_r(lpsolve('get_constraints', $lp));

lpsolve('delete_lp', $lp);

?>
